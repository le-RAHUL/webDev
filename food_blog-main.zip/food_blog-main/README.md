# Food Blog

after downloading the file , open the folder directory in code editor

run the following commands in terminal
  1.python manage.py runserver 
  the above command run the server 
  
 and the open this url in browser : http://121.0.0.1:8000/blog
 
 and then to create a super user 
 
 in terminal run the follwing command
  python manage.py createsuperuser
  
  and then 
  
  goto this url for admin site
  
  http://121.0.0.1:8000/admin
